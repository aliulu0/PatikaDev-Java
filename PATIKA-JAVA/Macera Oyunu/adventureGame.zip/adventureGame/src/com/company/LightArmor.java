package com.company;

public class LightArmor extends Armor{
    public LightArmor() {
        super(1,"Hafif",1,15);
    }
}
