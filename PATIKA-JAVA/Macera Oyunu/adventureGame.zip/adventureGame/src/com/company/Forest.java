package com.company;

public class Forest extends BattleLoc{
    public Forest(Player player) {
        super(player, 4,"Orman",new Vampire(),new Firewood(), 3,"Ormana git ve ödülünü al ! Ödül<Odun>");
    }
}
