package com.company;

public class Money extends Awards{
    public Money() {
        super(10, "Para");
    }
}
