package com.company;

public class Wolfman extends Monster{
    public Wolfman() {
        super(3,"Kurt Adam",7,20, new Money());
    }
}
