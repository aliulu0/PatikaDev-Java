package com.company;

public class Food extends Awards{
    public Food() {
        super(7,"Yemek");
    }
}
