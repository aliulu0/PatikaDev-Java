package com.company;

public class Mine extends BattleLoc{
    public Mine(Player player) {
        super(player, 6,"Maden", new Snake(),new RandomItem(), 6,"Madene git ve ödülünü al ! Ödül<?>");
    }
}
