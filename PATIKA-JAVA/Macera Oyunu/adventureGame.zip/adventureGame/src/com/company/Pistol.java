package com.company;

public class Pistol extends Weapon{
    public Pistol() {
        super("Silah", 1, 2, 15);
    }
}
