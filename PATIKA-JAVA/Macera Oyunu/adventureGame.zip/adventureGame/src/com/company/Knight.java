package com.company;

public class Knight extends GameCharacter{
    public Knight() {
        super(3, "Şovalye",8,24,5);
    }
}
