package com.company;

public class River extends BattleLoc{
    public River(Player player) {
        super(player, 5,"Nehir",new Wolfman(),new Water(), 3,"Nehir git ve ödülünü al ! Ödül<Su>");
    }
}
