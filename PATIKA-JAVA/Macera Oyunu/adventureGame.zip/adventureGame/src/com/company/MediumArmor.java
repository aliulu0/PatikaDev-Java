package com.company;

public class MediumArmor extends Armor{
    public MediumArmor() {
        super(2,"Orta",3,25);
    }
}
