package com.company;

public class Sword extends Weapon{
    public Sword() {
        super("Kılıç",2,3,35);
    }
}
