package com.company;

public class Samurai extends GameCharacter {

    public Samurai() {
        super(1, "Samuray",10, 41, 100);
    }
}
