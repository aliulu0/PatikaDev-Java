package com.company;

public class Firewood extends Awards{
    public Firewood() {
        super(8,"Odun");
    }
}
