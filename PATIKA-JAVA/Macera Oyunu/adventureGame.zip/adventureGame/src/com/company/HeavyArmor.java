package com.company;

public class HeavyArmor extends Armor{
    public HeavyArmor() {
        super(3,"Ağır",5,40);
    }
}
