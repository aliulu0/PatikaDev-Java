package com.company;

public class Awards extends Items{
    public Awards(int id, String name) {
        super(id, name);
    }
}
