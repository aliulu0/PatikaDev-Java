package com.company;

public class Water extends Awards{
    public Water() {
        super(9,"Su");
    }
}
